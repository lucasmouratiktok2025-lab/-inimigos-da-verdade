import { io, Socket } from "socket.io-client";

const SOCKET_URL = window.location.origin;

export const socket: Socket = io(SOCKET_URL, {
  autoConnect: true,
});

export interface SocketMessage {
  id: string;
  username: string;
  content: string;
  timestamp: Date;
}

export interface JoinRoomData {
  username: string;
  password: string;
}

export interface SendMessageData {
  content: string;
}
