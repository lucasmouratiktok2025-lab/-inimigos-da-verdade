import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export interface Message {
  id: string;
  username: string;
  content: string;
  timestamp: Date;
}

interface ChatMessageProps {
  message: Message;
  isOwnMessage: boolean;
}

function getAvatarColor(username: string): string {
  const colors = [
    "bg-blue-500",
    "bg-green-500",
    "bg-purple-500",
    "bg-pink-500",
    "bg-yellow-500",
    "bg-indigo-500",
    "bg-red-500",
    "bg-teal-500",
  ];
  
  const hash = username.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return colors[hash % colors.length];
}

function getInitials(username: string): string {
  return username.slice(0, 2).toUpperCase();
}

function formatTime(date: Date): string {
  return new Intl.DateTimeFormat('pt-BR', {
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

export default function ChatMessage({ message, isOwnMessage }: ChatMessageProps) {
  return (
    <div className="flex gap-3 p-3 hover-elevate rounded-md" data-testid={`message-${message.id}`}>
      <Avatar className="w-10 h-10 flex-shrink-0">
        <AvatarFallback className={`${getAvatarColor(message.username)} text-white text-sm font-semibold`}>
          {getInitials(message.username)}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline gap-2 mb-1">
          <span className="font-semibold text-sm text-foreground" data-testid={`text-username-${message.id}`}>
            {message.username}
            {isOwnMessage && <span className="text-muted-foreground font-normal ml-1">(você)</span>}
          </span>
          <span className="text-xs text-muted-foreground font-mono" data-testid={`text-timestamp-${message.id}`}>
            {formatTime(message.timestamp)}
          </span>
        </div>
        <p className="text-sm text-foreground break-words" data-testid={`text-content-${message.id}`}>
          {message.content}
        </p>
      </div>
    </div>
  );
}
