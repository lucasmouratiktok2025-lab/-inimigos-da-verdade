import { useState, useEffect, useRef } from "react";
import ChatHeader from "./ChatHeader";
import ChatMessage, { type Message } from "./ChatMessage";
import ChatInput from "./ChatInput";
import UserList from "./UserList";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { socket } from "@/lib/socket";

interface ChatRoomProps {
  currentUser: string;
  onLeave?: () => void;
}

export default function ChatRoom({ currentUser, onLeave }: ChatRoomProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [users, setUsers] = useState<string[]>([]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMessage = (message: Message) => {
      setMessages((prev) => [...prev, {
        ...message,
        timestamp: new Date(message.timestamp)
      }]);
    };

    const handleUsersUpdate = (userList: string[]) => {
      setUsers(userList);
    };

    const handleError = ({ message }: { message: string }) => {
      console.error("Socket error:", message);
    };

    socket.on("message", handleMessage);
    socket.on("users_update", handleUsersUpdate);
    socket.on("error", handleError);

    return () => {
      socket.off("message", handleMessage);
      socket.off("users_update", handleUsersUpdate);
      socket.off("error", handleError);
    };
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = (content: string) => {
    socket.emit("send_message", { content });
  };

  return (
    <div className="h-screen flex">
      <aside className="hidden lg:block w-60 flex-shrink-0">
        <UserList users={users} currentUser={currentUser} />
      </aside>

      <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
        <SheetContent side="left" className="p-0 w-60">
          <UserList users={users} currentUser={currentUser} />
        </SheetContent>
      </Sheet>

      <div className="flex-1 flex flex-col min-w-0">
        <ChatHeader
          roomName="sala-geral"
          onlineCount={users.length}
          onMenuClick={() => setMobileMenuOpen(true)}
        />

        <ScrollArea className="flex-1" ref={scrollRef}>
          <div className="p-4 space-y-2">
            {messages.map((message) => (
              <ChatMessage
                key={message.id}
                message={message}
                isOwnMessage={message.username === currentUser}
              />
            ))}
          </div>
        </ScrollArea>

        <ChatInput onSendMessage={handleSendMessage} />
      </div>
    </div>
  );
}
