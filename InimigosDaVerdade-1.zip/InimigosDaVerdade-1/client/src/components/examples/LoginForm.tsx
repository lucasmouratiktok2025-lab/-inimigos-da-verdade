import LoginForm from '../LoginForm';

export default function LoginFormExample() {
  return (
    <LoginForm 
      onLogin={(nickname) => console.log('Login with nickname:', nickname)} 
    />
  );
}
