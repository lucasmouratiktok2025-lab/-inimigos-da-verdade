import ChatRoom from '../ChatRoom';

export default function ChatRoomExample() {
  return <ChatRoom currentUser="Lucas" />;
}
