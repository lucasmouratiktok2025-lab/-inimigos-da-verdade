import ChatHeader from '../ChatHeader';

export default function ChatHeaderExample() {
  return (
    <ChatHeader 
      roomName="sala-geral" 
      onlineCount={12} 
      onMenuClick={() => console.log('Menu clicked')}
    />
  );
}
