import ChatMessage from '../ChatMessage';

export default function ChatMessageExample() {
  const mockMessage = {
    id: '1',
    username: 'Lucas',
    content: 'Olá pessoal! Esta é uma mensagem de exemplo no chat.',
    timestamp: new Date(),
  };

  return (
    <div className="bg-background p-4">
      <ChatMessage message={mockMessage} isOwnMessage={false} />
      <ChatMessage 
        message={{
          ...mockMessage,
          id: '2',
          username: 'Você',
          content: 'Esta é a sua mensagem!',
        }} 
        isOwnMessage={true} 
      />
    </div>
  );
}
