import UserList from '../UserList';

export default function UserListExample() {
  const mockUsers = ["Lucas", "Maria", "João", "Ana", "Pedro", "Carla"];
  
  return (
    <div className="h-screen">
      <UserList users={mockUsers} currentUser="Lucas" />
    </div>
  );
}
