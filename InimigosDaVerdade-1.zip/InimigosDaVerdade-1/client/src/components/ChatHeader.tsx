import { Menu, Hash } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ChatHeaderProps {
  roomName: string;
  onlineCount: number;
  onMenuClick: () => void;
}

export default function ChatHeader({ roomName, onlineCount, onMenuClick }: ChatHeaderProps) {
  return (
    <header className="h-14 border-b border-border bg-background px-4 flex items-center justify-between flex-shrink-0">
      <div className="flex items-center gap-3">
        <Button
          data-testid="button-menu-toggle"
          variant="ghost"
          size="icon"
          onClick={onMenuClick}
          className="lg:hidden"
        >
          <Menu className="w-5 h-5" />
        </Button>
        <div className="flex items-center gap-2">
          <Hash className="w-5 h-5 text-muted-foreground" />
          <h1 className="font-bold text-lg" data-testid="text-room-name">
            {roomName}
          </h1>
        </div>
      </div>
      <div className="text-sm text-muted-foreground" data-testid="text-online-count">
        {onlineCount} online
      </div>
    </header>
  );
}
