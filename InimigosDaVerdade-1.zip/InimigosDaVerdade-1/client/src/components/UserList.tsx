import { Users, User } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";

interface UserListProps {
  users: string[];
  currentUser: string;
}

function getAvatarColor(username: string): string {
  const colors = [
    "bg-blue-500",
    "bg-green-500",
    "bg-purple-500",
    "bg-pink-500",
    "bg-yellow-500",
    "bg-indigo-500",
    "bg-red-500",
    "bg-teal-500",
  ];
  
  const hash = username.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return colors[hash % colors.length];
}

function getInitials(username: string): string {
  return username.slice(0, 2).toUpperCase();
}

export default function UserList({ users, currentUser }: UserListProps) {
  return (
    <div className="h-full flex flex-col bg-sidebar border-r border-sidebar-border">
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-2 text-sidebar-foreground">
          <Users className="w-5 h-5" />
          <h2 className="font-semibold">Online ({users.length})</h2>
        </div>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          {users.map((user) => (
            <div
              key={user}
              className="flex items-center gap-3 p-2 rounded-md hover-elevate"
              data-testid={`user-item-${user}`}
            >
              <div className="relative">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className={`${getAvatarColor(user)} text-white text-xs font-semibold`}>
                    {getInitials(user)}
                  </AvatarFallback>
                </Avatar>
                <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-status-online rounded-full border-2 border-sidebar" />
              </div>
              <span className="text-sm text-sidebar-foreground font-medium truncate">
                {user}
                {user === currentUser && <span className="text-muted-foreground ml-1">(você)</span>}
              </span>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
