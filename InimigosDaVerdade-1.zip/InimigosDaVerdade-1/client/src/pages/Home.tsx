import { useState } from "react";
import LoginForm from "@/components/LoginForm";
import ChatRoom from "@/components/ChatRoom";
import { socket } from "@/lib/socket";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const { toast } = useToast();

  const handleLogin = (nickname: string) => {
    if (!socket.connected) {
      socket.connect();
    }

    const handleJoined = () => {
      setCurrentUser(nickname);
      socket.off("error", handleError);
    };

    const handleError = ({ message }: { message: string }) => {
      toast({
        title: "Erro ao entrar",
        description: message,
        variant: "destructive",
      });
      socket.off("joined", handleJoined);
    };

    socket.once("joined", handleJoined);
    socket.once("error", handleError);

    socket.emit("join", { username: nickname, password: "lucas123" });
  };

  const handleLeave = () => {
    socket.disconnect();
    setCurrentUser(null);
  };

  if (!currentUser) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return <ChatRoom currentUser={currentUser} onLeave={handleLeave} />;
}
