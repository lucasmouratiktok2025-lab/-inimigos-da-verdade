# Design Guidelines: Inimigos da Verdade 02

## Design Approach
**Reference-Based: Discord-Inspired Chat Interface**

Drawing from Discord's functional design language while maintaining a clean, focused single-room chat experience. Emphasis on readability, efficiency, and mobile-first responsive design.

## Typography System

**Font Families:**
- Primary: 'Inter' or 'Roboto' (Google Fonts)
- Monospace: 'Roboto Mono' for timestamps/system messages

**Hierarchy:**
- Chat messages: text-sm (14px), font-normal
- Usernames: text-sm, font-semibold
- Timestamps: text-xs (12px), font-normal
- Input field: text-base (16px)
- Room title: text-lg, font-bold
- System messages: text-xs, italic

## Spacing System

**Tailwind Units:** Consistently use 2, 4, 6, 8, 12, 16, 24 for spacing
- Message padding: p-3 (vertical) px-4 (horizontal)
- Input container: p-4
- Sidebar padding: p-4
- Message gaps: space-y-2
- Section gaps: space-y-6

## Layout Structure

### Login Screen
- Centered card (max-w-md)
- Vertical form layout with generous spacing (space-y-6)
- Logo/title at top
- Nickname input field
- Password input field
- Enter button (full width)
- Mobile: Full-screen centered with padding

### Chat Interface

**Desktop Layout (lg breakpoint and above):**
- Three-column grid: `grid-cols-[240px,1fr]`
- Left sidebar: User list (240px fixed width)
- Main area: Chat messages + input

**Mobile Layout (base to md):**
- Single column, full-width chat
- Hamburger menu reveals user list as slide-over overlay
- Bottom-fixed input area

**Header Bar:**
- Fixed top, full width
- Room name on left
- User count indicator
- Mobile: Menu toggle button

**Sidebar (Desktop):**
- Fixed height, scrollable user list
- Each user: avatar placeholder + username
- Online indicator (small dot)
- "Active Users" header

**Messages Area:**
- Flex column, reverse scroll (newest at bottom)
- Auto-scroll to latest message
- Each message container: flex row
  - Avatar circle (8x8 or 10x10)
  - Message content: username + timestamp on first line, message text below
- Hover state: subtle treatment on message row

**Input Area:**
- Fixed bottom (mobile) or bottom of chat container (desktop)
- Single-line text input with auto-expand
- Send button (icon-only on mobile, with text on desktop)
- Border separator above

## Component Library

### Cards & Containers
- Login card: rounded-xl, shadow-xl
- Message bubbles: No explicit bubbles, Discord-style flat rows
- Sidebar: Subtle border separator

### Form Elements
- Input fields: rounded-lg, border, px-4 py-3
- Focus state: ring treatment
- Error state: red border for wrong password

### Buttons
- Primary (Send/Enter): rounded-lg, px-6 py-3, font-semibold
- Icon button (mobile send): rounded-full, p-3

### User List Items
- Each user row: flex items-center, gap-3, p-2, rounded-md
- Hover: subtle treatment
- Avatar: rounded-full, size-8 or size-10

### Message Components
- Username: font-semibold, inline
- Timestamp: text-xs, opacity-70, ml-2, inline
- Message text: mt-1, word-wrap

## Mobile Optimizations

**Breakpoint Strategy:**
- Mobile first: base styles
- Tablet: md: (768px)
- Desktop: lg: (1024px)

**Mobile-Specific:**
- Input area: sticky bottom with safe-area padding
- User list: slide-over drawer (fixed overlay with backdrop blur)
- Touch-friendly tap targets: minimum 44x44px
- Reduced padding in messages (p-2 instead of p-3)
- Larger font size in input (16px to prevent zoom on iOS)

## Accessibility

- Semantic HTML: `<main>`, `<aside>`, `<form>`, `<ul>` for messages
- ARIA labels: "Chat messages", "User list", "Message input"
- Focus management: auto-focus input on load
- Keyboard navigation: Enter to send, Tab through interface
- Alt text for user avatars with username

## Icons

**Library:** Heroicons (via CDN)
- Send icon for submit button
- Menu icon for mobile navigation
- User icon for avatar placeholders
- Check/online indicator (solid circle)

## Animations

**Minimal, Functional Only:**
- New message: simple fade-in (0.2s)
- Slide-over drawer: transform-x transition (0.3s ease)
- Button states: no animations, instant feedback
- No scroll animations or decorative effects

## Images

**No hero images or decorative imagery**

This is a functional chat application - all visual elements are UI components. User avatars use icon placeholders (user icon in colored circle background based on username hash for variety).