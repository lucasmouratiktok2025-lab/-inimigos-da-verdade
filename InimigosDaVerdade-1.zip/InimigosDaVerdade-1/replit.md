# Inimigos da Verdade 02 - Chat Application

## Overview

A real-time chat application built with React, Express, and Socket.IO. This is a single-room chat system with password-protected access, featuring a Discord-inspired interface with user presence tracking and instant messaging capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with TypeScript for the UI layer
- **Vite** as the build tool and development server
- **Wouter** for client-side routing (lightweight alternative to React Router)

**State Management**
- **TanStack Query (React Query)** for server state management and caching
- Local component state with React hooks for UI state
- Socket.IO client for real-time bidirectional communication

**UI Components**
- **shadcn/ui** component library built on Radix UI primitives
- **Tailwind CSS** for styling with custom design tokens
- Dark mode support with CSS variables for theming
- Mobile-first responsive design with breakpoint-based layouts

**Design System**
- Typography: Inter (primary), Roboto Mono (monospace)
- Discord-inspired chat interface with clean, functional design
- Consistent spacing system using Tailwind's scale (2, 4, 6, 8, 12, 16, 24)
- Custom color system with HSL values for light/dark mode support

### Backend Architecture

**Server Framework**
- **Express.js** as the HTTP server
- **Socket.IO** for WebSocket-based real-time communication
- HTTP server wraps Express to enable Socket.IO integration

**Authentication & Authorization**
- Password-based room access (hardcoded password: "lucas123")
- Username uniqueness validation per session
- No persistent user accounts - session-based only

**Data Storage**
- **In-Memory Storage** (MemStorage class) for user data
- No database persistence - all data lives in memory
- User data includes: id, username, password (if implementing persistent users)
- Chat messages and online users stored in memory during runtime only

**Real-Time Communication**
- Socket.IO rooms for chat segregation (currently single room: "sala-geral")
- Event-based architecture for join/leave, messages, and user updates
- Automatic user list synchronization on connect/disconnect

### External Dependencies

**Core Runtime**
- **Node.js** with ES modules (type: "module")
- TypeScript for type safety across client and server

**Database & ORM**
- **Drizzle ORM** configured for PostgreSQL (via `@neondatabase/serverless`)
- Schema defines users table with id, username, password
- Migration setup in place but not actively used (in-memory storage currently active)
- Database URL expected via `DATABASE_URL` environment variable

**Third-Party Services**
- **Google Fonts** for Inter and Roboto Mono font families
- **Socket.IO** for WebSocket transport layer

**UI Component Libraries**
- **Radix UI** primitives for accessible, unstyled components
- **Lucide React** for iconography
- **date-fns** for date/time formatting
- **class-variance-authority** and **clsx** for conditional styling

**Development Tools**
- **tsx** for running TypeScript in development
- **esbuild** for production server bundling
- **Replit plugins** for development experience (cartographer, dev banner, runtime error overlay)

**Session Management**
- **express-session** with **connect-pg-simple** configured for PostgreSQL session store
- Currently using in-memory session storage as database is not actively connected

### Key Architectural Decisions

**Real-Time Communication Pattern**
- Socket.IO chosen over raw WebSockets for automatic reconnection, room management, and fallback transports
- Event-driven architecture separates concerns (join, message, users_update, error events)
- Bi-directional communication enables instant message delivery and user presence updates

**State Management Strategy**
- React Query handles API calls and caching (though minimal REST API currently)
- Socket.IO events trigger local state updates for real-time data
- No global state management library needed due to simple single-room architecture

**Storage Abstraction**
- `IStorage` interface allows swapping between in-memory and database storage
- Current implementation uses `MemStorage` for simplicity
- Drizzle ORM configured for future PostgreSQL integration if persistence needed

**Routing & Navigation**
- Single-page application with minimal routing (login vs. chat)
- Wouter provides lightweight routing without React Router overhead
- Conditional rendering based on user authentication state

**Styling Approach**
- Utility-first with Tailwind CSS for rapid development
- CSS variables enable theme switching and consistent design tokens
- Component-level styling with `cn()` utility for conditional classes
- shadcn/ui provides pre-built accessible components with customizable styling

**Security Considerations**
- Hardcoded password is a temporary solution (not production-ready)
- Username uniqueness prevents impersonation within active sessions
- No XSS protection beyond React's default escaping
- Socket.IO CORS set to allow all origins (development configuration)