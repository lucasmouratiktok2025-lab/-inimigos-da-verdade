import type { Express } from "express";
import { createServer, type Server } from "http";
import { Server as SocketServer } from "socket.io";
import type { ChatMessage, OnlineUser } from "@shared/schema";

const ROOM_PASSWORD = "lucas123";
const ROOM_NAME = "sala-geral";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  const io = new SocketServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  const onlineUsers = new Map<string, OnlineUser>();

  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("join", ({ username, password }: { username: string; password: string }) => {
      if (password !== ROOM_PASSWORD) {
        socket.emit("error", { message: "Senha incorreta" });
        return;
      }

      const existingUser = Array.from(onlineUsers.values()).find(
        (user) => user.username === username
      );

      if (existingUser) {
        socket.emit("error", { message: "Nickname já está em uso" });
        return;
      }

      onlineUsers.set(socket.id, { socketId: socket.id, username });
      socket.join(ROOM_NAME);

      socket.emit("joined", { username });

      const userList = Array.from(onlineUsers.values()).map((u) => u.username);
      io.to(ROOM_NAME).emit("users_update", userList);

      const systemMessage: ChatMessage = {
        id: Date.now().toString(),
        username: "Sistema",
        content: `${username} entrou no chat`,
        timestamp: new Date(),
      };
      io.to(ROOM_NAME).emit("message", systemMessage);

      console.log(`${username} joined the room. Total users: ${onlineUsers.size}`);
    });

    socket.on("send_message", ({ content }: { content: string }) => {
      const user = onlineUsers.get(socket.id);
      if (!user) {
        socket.emit("error", { message: "Você precisa entrar na sala primeiro" });
        return;
      }

      const message: ChatMessage = {
        id: `${socket.id}-${Date.now()}`,
        username: user.username,
        content,
        timestamp: new Date(),
      };

      io.to(ROOM_NAME).emit("message", message);
      console.log(`Message from ${user.username}: ${content}`);
    });

    socket.on("disconnect", () => {
      const user = onlineUsers.get(socket.id);
      if (user) {
        onlineUsers.delete(socket.id);
        
        const systemMessage: ChatMessage = {
          id: Date.now().toString(),
          username: "Sistema",
          content: `${user.username} saiu do chat`,
          timestamp: new Date(),
        };
        io.to(ROOM_NAME).emit("message", systemMessage);

        const userList = Array.from(onlineUsers.values()).map((u) => u.username);
        io.to(ROOM_NAME).emit("users_update", userList);

        console.log(`${user.username} left the room. Total users: ${onlineUsers.size}`);
      }
      console.log("User disconnected:", socket.id);
    });
  });

  return httpServer;
}
